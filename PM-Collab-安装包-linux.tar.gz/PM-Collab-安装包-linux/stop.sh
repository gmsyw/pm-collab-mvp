#!/bin/sh
# 停止 PM-Collab 服务。
DIR=$(cd "$(dirname "$0")" && pwd)
PIDF="$DIR/pmcollab.pid"

if [ -f "$PIDF" ]; then
  PID=$(cat "$PIDF")
  if kill -0 "$PID" 2>/dev/null; then
    kill "$PID" && echo "已停止（PID $PID）"
  else
    echo "进程已不在运行"
  fi
  rm -f "$PIDF"
fi

pkill -f "uvicorn server.app.main:app" >/dev/null 2>&1 && echo "已停止残留 uvicorn 进程" || true
