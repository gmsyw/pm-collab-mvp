#!/bin/sh
# 启动 PM-Collab 服务（端口默认 8731，可用环境变量 PM_PORT 覆盖）。
DIR=$(cd "$(dirname "$0")" && pwd)
PY="$DIR/python/bin/python3"
PORT="${PM_PORT:-8731}"

if [ ! -x "$PY" ]; then
  echo "未找到 $PY，请先运行 ./fetch_python.sh 与 ./setup.sh。"
  exit 1
fi

cd "$DIR"
export PYTHONPATH="$DIR"

echo "启动 PM-Collab（端口 $PORT）..."
nohup "$PY" -m uvicorn server.app.main:app --host 127.0.0.1 --port "$PORT" \
  > "$DIR/pmcollab.log" 2>&1 &
PID=$!
echo "$PID" > "$DIR/pmcollab.pid"

READY=0
for i in $(seq 1 40); do
  sleep 1
  if curl -fsS "http://127.0.0.1:$PORT/api/report/heartbeat" >/dev/null 2>&1; then READY=1; break; fi
  if ! kill -0 "$PID" 2>/dev/null; then
    echo "服务进程异常退出，请查看 $DIR/pmcollab.log"
    break
  fi
done

if [ "$READY" -eq 1 ]; then
  echo "PM-Collab 已启动： http://127.0.0.1:$PORT"
  echo "默认管理员账号： admin / 首次启动随机口令（见控制台输出）"
  echo "（停止请运行 ./stop.sh，或关闭该进程）"
  if command -v xdg-open >/dev/null 2>&1; then
    xdg-open "http://127.0.0.1:$PORT/" >/dev/null 2>&1 &
  fi
else
  echo "未能在限定时间内就绪，请查看 $DIR/pmcollab.log"
fi
