#!/bin/sh
# 安装运行依赖（离线，来自 wheels/）。可重复执行，幂等。
DIR=$(cd "$(dirname "$0")" && pwd)
PY="$DIR/python/bin/python3"

if [ ! -x "$PY" ]; then
  echo "未找到 $PY，请先运行 ./fetch_python.sh 拉取可移植 Python。"
  exit 1
fi

echo "安装运行依赖（离线，来自 wheels/）..."
"$PY" -m pip install --no-index --find-links "$DIR/wheels" \
  -r "$DIR/requirements-runtime.txt" --no-warn-script-location
echo "依赖安装完成。"
