#!/bin/sh
# 拉取可移植 Linux Python 3.11（仅首次需联网，约 40MB），之后完全离线。
set -e
DIR=$(cd "$(dirname "$0")" && pwd)
VER=20250812
FILE="cpython-3.11.14+${VER}-x86_64-unknown-linux-gnu-install_only.tar.gz"
URLS="
https://github.com/astral-sh/python-build-standalone/releases/download/${VER}/${FILE}
https://mirrors.huaweicloud.com/github-release/astral-sh/python-build-standalone/${VER}/${FILE}
"

if [ -x "$DIR/python/bin/python3" ]; then
  echo "python/ 已存在，跳过下载。如需重新拉取请先删除 python/ 目录。"
  exit 0
fi

TMP=$(mktemp -d)
OK=0
for u in $URLS; do
  echo "尝试下载：$u"
  if command -v curl >/dev/null 2>&1; then
    if curl -fL "$u" -o "$TMP/$FILE"; then OK=1; break; fi
  elif command -v wget >/dev/null 2>&1; then
    if wget -O "$TMP/$FILE" "$u"; then OK=1; break; fi
  fi
done

if [ "$OK" -ne 1 ]; then
  echo "下载失败。请手动下载以下文件并解压到本目录的 python/ 子目录："
  echo "  $FILE"
  echo "  https://github.com/astral-sh/python-build-standalone/releases/download/${VER}/${FILE}"
  rm -rf "$TMP"
  exit 1
fi

echo "解压到 $DIR/python ..."
tar -xzf "$TMP/$FILE" -C "$DIR"
chmod -R +x "$DIR/python/bin" 2>/dev/null || true
echo "完成。接下来请运行 ./setup.sh 安装依赖。"
rm -rf "$TMP"
