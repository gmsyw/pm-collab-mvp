#!/bin/sh
# 一次性：安装依赖并启动（需先已运行过 ./fetch_python.sh）。
DIR=$(cd "$(dirname "$0")" && pwd)
"$DIR/setup.sh"
"$DIR/start.sh"
