@echo off
chcp 65001 >nul
cd /d "%~dp0"

if not exist "python\python.exe" (
    echo [错误] 未找到内置 Python（python\python.exe），请确认压缩包已完整解压。
    pause
    exit /b 1
)

echo PM-Collab 启动中...
start "PM-Collab" cmd /k "python\python.exe -m uvicorn server.app.main:app --host 127.0.0.1 --port 8731"
timeout /t 6 >nul
powershell -NoProfile -Command "try { $c=(Invoke-WebRequest -Uri 'http://127.0.0.1:8731/api/report/heartbeat' -UseBasicParsing -TimeoutSec 5).StatusCode; if($c -eq 200){Write-Host '服务已就绪，可访问。'} else {Write-Host \"服务返回 $c\"} } catch { Write-Host '服务暂未就绪，请查看 PM-Collab 窗口的报错，或稍后刷新浏览器。' }"
start http://127.0.0.1:8731
echo.
echo PM-Collab 已启动： http://127.0.0.1:8731
echo 默认管理员账号： admin / 首次启动随机口令（见 PM-Collab 窗口/控制台输出的初始口令）
echo （关闭“PM-Collab”窗口即停止；或用“停止.bat”）
pause
