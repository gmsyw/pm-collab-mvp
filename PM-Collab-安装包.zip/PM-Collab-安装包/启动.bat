@echo off
chcp 65001 >nul
cd /d "%~dp0"
if not exist "python\python.exe" (
    echo 未找到内置 Python（python\python.exe），请确认压缩包已完整解压。
    pause
    exit /b 1
)
start "PM-Collab" cmd /k "python\python.exe -m uvicorn server.app.main:app --host 127.0.0.1 --port 8731"
timeout /t 6 >nul
start http://127.0.0.1:8731
echo PM-Collab 已启动： http://127.0.0.1:8731
echo 默认管理员账号： admin / 首次启动随机口令（见 PM-Collab 窗口/控制台输出的初始口令）
pause
