@echo off
chcp 65001 >nul
for /f "tokens=5" %%a in ('netstat -ano ^| findstr :8731 ^| findstr LISTENING') do taskkill /PID %%a /F >nul 2>&1
echo 已请求停止 PM-Collab（端口 8731）。
pause
